    <script src="<?= BASEURL?>/js/jquery.min.js"></script>
    <script src="<?= BASEURL?>/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="<?= BASEURL?>/js/script.min.js"></script>
    <script src="<?= BASEURL?>/js/script.js"></script>
</html>