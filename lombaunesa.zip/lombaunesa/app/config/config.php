<?php

define('BASEURL', 'http://localhost/lombaunsri');

//DB
define('DB_HOST', 'localhost');
define('DB_NAME', 'lombaunsri');
define('DB_USER', 'root');
define('DB_PASS', '');
