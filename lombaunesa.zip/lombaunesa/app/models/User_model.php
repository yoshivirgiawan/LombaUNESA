<?php

class User_model {
    private $nama = 'Yoshi';

    public function getUser() {
        return $this->nama;
    }
}